from collections import deque

# BFS function
def bfs(graph, start_node):
    visited = set()  # Set to keep track of visited nodes
    queue = deque([start_node])  # Queue for BFS, starts with the start node
    
    while queue:
        node = queue.popleft()  # Dequeue the front node
        if node not in visited:
            print(node, end=" ")  # Print the node
            visited.add(node)  # Mark node as visited
            # Enqueue all the unvisited neighbors of the current node
            for neighbor in graph[node]:
                if neighbor not in visited:
                    queue.append(neighbor)

# Example graph (represented as an adjacency list)
graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

# Start BFS traversal from node 'A'
print("Breadth-First Search starting from node 'A':")
bfs(graph, 'A')